# K. Vineeth Reddy — Portfolio

Responsive personal portfolio for GitHub Pages.

## Included
- `index.html` — page content and portfolio sections
- `style.css` — responsive styling and decorative graphics
- `script.js` — mobile navigation and current-year footer
- `README.md` — publishing instructions

## Publish
1. Extract this ZIP.
2. Create a new GitHub repository.
3. Upload all four files to the repository root.
4. Open **Settings → Pages**.
5. Choose **Deploy from a branch**, select `main` and `/(root)`, then Save.
6. Open the GitHub Pages URL once deployment completes.

## Important personalization note
The project cards and milestones are starter examples, not independently verified personal accomplishments. Keep only items that accurately describe work you have done. Update the email link in `index.html` from `your.email@example.com` to your real contact email before publishing. Also adjust the listed skills to match your current level.
